package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Add operation.
 */
public class Remainder {
    // TODO -- start your code here
    public String remainder(int arg1, int arg2) {
        return Integer.toString(arg1%arg2);// return the added value
    }
}
