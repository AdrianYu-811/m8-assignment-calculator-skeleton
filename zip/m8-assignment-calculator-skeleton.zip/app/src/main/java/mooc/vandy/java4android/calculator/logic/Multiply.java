package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Multiply operation.
 */
public class Multiply {
    // TODO -- start your code here
    public String multiply(int arg1, int arg2) {
        return Integer.toString(arg1 * arg2);//  return multiplied value
    }

}
