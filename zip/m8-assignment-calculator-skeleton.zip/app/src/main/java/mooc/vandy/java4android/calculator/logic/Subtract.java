package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Subtract operation.
 */
public class Subtract {
    // TODO -- start your code here
    public String subtract(int arg1, int arg2) {
        return Integer.toString(arg1 - arg2);// return subtracted value
    }

}
